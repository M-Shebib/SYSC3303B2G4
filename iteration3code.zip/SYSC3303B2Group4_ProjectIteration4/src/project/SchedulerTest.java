/**
 * 
 */
package project;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * @author shebib7290696
 *
 */
class SchedulerTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
